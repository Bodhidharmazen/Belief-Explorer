# Belief Explorer

A multi-perspective critical thinking analysis system designed to help users examine and reflect on their beliefs.

## Setup Instructions

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Create a `.env` file based on `.env.example` and add your Gemini API key:
   ```
   GEMINI_API_KEY=your_gemini_api_key_here
   PORT=5000
   FLASK_ENV=production
   ```

3. Run the application:
   ```
   python run.py
   ```

4. Access the application at http://localhost:5000

## Deployment Options

### Option 1: Deploy as a standalone web application
- Host the backend on a VPS or cloud service (AWS, GCP, DigitalOcean, etc.)
- Use Gunicorn as a production WSGI server:
  ```
  gunicorn -w 4 -b 0.0.0.0:5000 run:app
  ```
- Set up Nginx as a reverse proxy (recommended for production)

### Option 2: Deploy frontend and backend separately
- Host the frontend on GitHub Pages or any static hosting service
- Deploy the backend as an API service
- Update the API_URL in static/js/main.js to point to your backend URL
